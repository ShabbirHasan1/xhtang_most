#include <cstdint>

#define factor_t uint64_t

factor_t M = 20220217214410;
void init() {}

#include "checkerV4.h"
