#include <cstdint>
#include <climits>
#include <cassert>
#include <algorithm>

#define factor_t uint64_t

// #define FACTOR
// const int n_factor = 3;
// factor_t factors[n_factor] = {
// 500000000000000147ULL,
// 500000000000000207ULL,
// 500000000000000209ULL,
// };

// only check one factor
factor_t M = 500000000000000147ULL;

void init()
{
}

#include "checkerV4.h"
